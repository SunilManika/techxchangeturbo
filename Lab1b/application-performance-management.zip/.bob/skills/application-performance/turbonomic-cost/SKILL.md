---
name: turbonomic-cost
description: Use when the user wants to query Turbonomic cloud cost data — covers cost tag keys, billing data availability for AWS/Azure/GCP, and cost statistics grouped by time range or tag.
---

# Turbonomic Cost

This skill guides you through querying cloud cost data from Turbonomic via the MCP server tools.

## Prerequisites

The Turbonomic MCP server must be running and connected. Verify with:
- Environment variables set: `TURBONOMIC_API_URL`, `TURBONOMIC_USERNAME`, `TURBONOMIC_PASSWORD`
- Server started via `python fastmcp_server.py`

---

## Step 1 — Determine the User's Intent

Ask what the user needs:
- Discover what cost tags exist → use `get_cost_tag_keys`
- Check which cloud accounts have billing data → use `get_billing_data_availability`
- Retrieve cost totals / breakdowns for a time range → use `get_cost_statistics`

---

## Step 2 — Tool Reference

### Get Cost Tag Keys
```
get_cost_tag_keys
  scope_id   (optional str) — UUID of a scope (default: global market)
  start_time (optional str) — period start; default "-7d"
                              Formats: ISO 8601, milliseconds, or relative (-5h, -3d, -2w)
  end_time   (optional str) — period end; omit for "up to now"
```
Returns the list of tag key names available for cost filtering.

### Get Billing Data Availability
```
get_billing_data_availability
  cloud_types (optional list[str]) — filter by cloud: ["AWS"], ["Azure"], ["GCP"], or any combo
  limit       (optional int)       — max accounts to return
```
Returns BillingFamilies and BusinessAccounts with a flag indicating whether billing data is
available or unavailable for each.

### Get Cost Statistics
```
get_cost_statistics
  tag_filters    (optional list[dict]) — list of tag filter objects. Each dict must have:
                     "tagKey"    (str)       — the tag key name, e.g. "Environment"
                     "tagValues" (list[str]) — list of values to match, e.g. ["prod", "staging"]
                   Example: [{"tagKey": "Environment", "tagValues": ["prod"]}]
                   Required (non-empty) when cost_group_bys includes "TAG"
  cost_group_bys (optional list[str])  — group dimensions, e.g. ["ACCOUNT", "SERVICE", "TAG"]
  start_date     (optional str)        — period start (ISO 8601 or relative)
  end_date       (optional str)        — period end (ISO 8601 or relative)
```
When `start_date` and `end_date` are omitted, current (real-time) stats are returned.

---

## Step 3 — Interpret and Present Results

### Cost Tag Keys
- Response is a list of tag key strings like `"Environment"`, `"CostCenter"`, `"Project"`.
- Use these as input to `get_cost_statistics` tag filters.

### Billing Data Availability
- Each entry has an account name/ID and a `billingDataAvailability` flag (`AVAILABLE` / `UNAVAILABLE`).
- Filter by `cloud_types` to scope to a specific provider.

### Cost Statistics
- Results include cost values per grouping dimension (account, service, tag, etc.).
- Costs are typically expressed in USD.
- If no results, widen the date range or remove tag filters.

---

## Step 4 — Common Workflows

### Workflow: Understand Cost by Environment Tag
1. Call `get_cost_tag_keys()` to confirm the "Environment" tag key exists.
2. Call `get_cost_statistics(tag_filters=[{"tagKey": "Environment", "tagValues": ["prod"]}], cost_group_bys=["TAG"], start_date="-30d")`.
3. Present a breakdown of prod costs over the last 30 days.

### Workflow: Audit AWS Billing Coverage
1. Call `get_billing_data_availability(cloud_types=["AWS"])`.
2. Identify accounts where `billingDataAvailability` is `UNAVAILABLE`.
3. Report accounts missing billing data so the user can investigate in AWS.

### Workflow: Monthly Cost Report
1. Call `get_cost_statistics(start_date="2024-01-01T00:00:00Z", end_date="2024-01-31T23:59:59Z", cost_group_bys=["ACCOUNT", "SERVICE"])`.
2. Summarise total cost per account and per service for the month.

---

## Notes

- Relative time format: `m` = minutes, `h` = hours, `d` = days, `w` = weeks, `M` = months, `y` = years. Example: `-30d` = last 30 days.
- `tag_filters` is **required** and must be non-empty when `cost_group_bys` includes `"TAG"`.
- All tools return a dict; on failure the dict contains an `"error"` key with a description.
