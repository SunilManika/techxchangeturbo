---
name: turbonomic-policies
description: Use when the user wants to query, inspect, create, or manage Turbonomic placement policies or settings (automation) policies — covers GET/POST /policies for placement policies and GET/POST /settingspolicies for automation/settings policies.
---

# Turbonomic Policies

This skill covers both placement policies (`/policies`) and settings/automation policies (`/settingspolicies`).

## API Reference
- IBM Docs (Policies): https://www.ibm.com/docs/en/tarm/8.20.0?topic=endpoints-policies-endpoint

---

## Endpoint Groups

### 1. Placement Policies — /api/v3/policies

Placement policies control how entities can be placed relative to each other (HA, DRS, segment).

#### GET /api/v3/policies
Returns all placement policies.

**Query parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `limit` | int | Max policies to return |
| `cursor` | str | Pagination cursor |

**Response item shape:**
```json
{
  "uuid": "287733992157344",
  "displayName": "[HA]NodeRole::master [Kubernetes-Turbonomic]",
  "type": "MUST_NOT_RUN_TOGETHER",
  "name": "...",
  "enabled": true,
  "commodityType": "DrsSegmentationCommodity",
  "consumerGroup": {
    "uuid": "...",
    "displayName": "NodeRole-master-Kubernetes-Turbonomic",
    "groupType": "VirtualMachine",
    "membersCount": 3
  }
}
```

**Policy types:**
| Type | Description |
|------|-------------|
| `MUST_RUN_TOGETHER` | Entities must be co-located |
| `MUST_NOT_RUN_TOGETHER` | Entities must be separated (HA) |
| `BIND_TO_GROUP` | Entities must run on a specific provider group |
| `MUST_RUN_ON` | Entity must run on a specific host/cluster |
| `AT_MOST_N` | At most N consumers per provider |
| `AT_MOST_N_BOUND` | Bounded version of AT_MOST_N |

---

### 2. Settings / Automation Policies — /api/v3/settingspolicies

Settings policies control action automation, utilisation thresholds, and operational constraints per entity type.

#### GET /api/v3/settingspolicies
Returns all settings policies (one per entity type by default, plus user-defined overrides).

**Response item shape:**
```json
{
  "uuid": "287733981134640",
  "displayName": "Switch Defaults",
  "entityType": "Switch",
  "settingsManagers": [
    {
      "uuid": "marketsettingsmanager",
      "displayName": "Operational Constraints",
      "category": "Analysis",
      "settings": [
        {
          "uuid": "netThroughput",
          "displayName": "Net Throughput",
          "value": "70.0",
          "defaultValue": "50.0",
          "valueType": "NUMERIC",
          "min": 0.0,
          "max": 100.0
        }
      ]
    }
  ]
}
```

**Entity types with settings policies** (sample):
`VirtualMachine`, `PhysicalMachine`, `Storage`, `DatabaseServer`, `Container`, `ContainerSpec`,
`Namespace`, `WorkloadController`, `ApplicationComponent`, `BusinessTransaction`,
`Service`, `DiskArray`, `Switch`, `DataCenter`, `StorageController`

**Common settings categories:**
| Category | Description |
|----------|-------------|
| `Analysis` | Utilisation thresholds and operational constraints |
| `ActionAutomation` | Which action types are automated vs. manual |
| `ActionScript` | Custom scripts on action execution |
| `Scaling` | Min/max scaling constraints |

---

## Step 1 — Determine Intent

| User asks for… | Endpoint |
|----------------|----------|
| All placement / HA policies | `GET /policies` |
| Policy details for a specific UUID | `GET /policies/{uuid}` |
| Automation settings for all entity types | `GET /settingspolicies` |
| Settings for a specific entity type | `GET /settingspolicies?entityType=VirtualMachine` |
| Create a new placement policy | `POST /policies` |
| Update a settings policy | `PUT /settingspolicies/{uuid}` |

---

## Step 2 — Proxy Routes (localhost:4000)

| Proxy route | Turbonomic endpoint |
|---|---|
| `GET /api/policies` | `GET /api/v3/policies` |
| `GET /api/settingspolicies` | `GET /api/v3/settingspolicies` |

> Note: `/turbo/*` prefix is **not used**. All proxy routes use `/api/*`.

---

## Step 3 — Common Workflows

### Workflow: Audit HA Placement Policies
1. Call `GET /api/v3/policies`.
2. Filter for `type === "MUST_NOT_RUN_TOGETHER"`.
3. For each, show `displayName`, `consumerGroup.displayName`, and `consumerGroup.membersCount`.

### Workflow: Review Automation Settings for VMs
1. Call `GET /api/v3/settingspolicies`.
2. Filter for `entityType === "VirtualMachine"`.
3. Within `settingsManagers`, locate the `ActionAutomation` category.
4. Show each action type and whether it is `AUTOMATIC`, `MANUAL`, or `DISABLED`.

### Workflow: Check Utilisation Thresholds
1. Call `GET /api/v3/settingspolicies`.
2. For the relevant entity type, find the `Analysis` settings manager.
3. Compare `value` vs `defaultValue` for each threshold setting.
4. Flag any settings deviating from default.

---

## Notes
- Placement policies govern entity placement and segment constraints in the Turbonomic market.
- Settings policies control action automation modes and utilisation thresholds per entity type.
- `settingspolicies` returns one entry per entity type for default policies, plus any user-defined overrides.
- Mutating endpoints (`POST`, `PUT`, `DELETE`) require admin privileges — confirm intent before calling.
- Policy UUIDs are stable across sessions and can be cached for lookup.
