---
name: turbonomic-entities
description: Use when the user wants to query Turbonomic infrastructure entities, groups, targets, markets, reservations, entity policies, entity statistics, or entity governance — covers get_entities, get_groups, get_targets, get_markets, get_reservations, get_entity_stats, get_entity_policies, get_entity_settings_policies, and get_entity_governance.
---

# Turbonomic Entities

This skill guides you through querying Turbonomic infrastructure objects (entities, groups, targets,
markets, and reservations) via the MCP server tools.

## Prerequisites

The Turbonomic MCP server must be running and connected. Verify with:
- Environment variables set: `TURBONOMIC_API_URL`, `TURBONOMIC_USERNAME`, `TURBONOMIC_PASSWORD`
- Server started via `python fastmcp_server.py` (basic) or `python fastmcp_server_semantics.py` (includes entity governance tool)

---

## Step 1 — Determine the User's Intent

Identify which object type the user needs:

| User asks about…               | Tool to use                |
|--------------------------------|----------------------------|
| VMs, applications, hosts       | `get_entities`             |
| Business groups, clusters      | `get_groups`               |
| Discovered targets/probes      | `get_targets`              |
| Market simulation data         | `get_markets`              |
| Scheduled reservations         | `get_reservations`         |
| Resource stats for an entity   | `get_entity_stats`         |
| Placement policies for entity  | `get_entity_policies`      |
| Automation policies for entity | `get_entity_settings_policies` |
| Full policy/governance audit   | `get_entity_governance` (semantics server) |

---

## Step 2 — Tool Reference

### Get Entities
```
get_entities
  entity_type (optional str) — entity class filter, e.g. "VirtualMachine", "PhysicalMachine",
                               "Application", "Storage", "DatabaseServer", "Container"
  limit       (optional int) — max entities to return
```
Without `entity_type`, returns all entity types. Use `limit` to avoid very large responses.

### Get Groups
```
get_groups
  group_type (optional str) — group class filter, e.g. "BusinessApplication", "VirtualMachine",
                              "Cluster", "DataCenter"
  limit      (optional int) — max groups to return
```

### Get Targets
```
get_targets
  target_type (optional str) — target/probe type filter, e.g. "vCenter", "AWS", "Azure",
                               "Kubernetes", "AppDynamics"
  limit       (optional int) — max targets to return
```

### Get Markets
```
get_markets
  (no parameters)
```
Returns the list of markets (economy simulations) including the real-time market.

### Get Reservations
```
get_reservations
  limit (optional int) — max reservations to return
```

### Get Entity Statistics
```
get_entity_stats
  entity_uuid    (required str) — UUID of the entity
  encoded_query  (optional str) — URL-encoded query string for filtering stats,
                                  e.g. "startDate=1767740100653&endDate=1767774010065"
```
Returns resource utilisation statistics (CPU, memory, storage, etc.) for the entity.
If `encoded_query` is omitted, returns current stats.

### Get Entity Placement Policies
```
get_entity_policies
  entity_uuid (required str) — UUID of the entity
```
Returns the placement and operational policies that govern where/how this entity can run.

### Get Entity Automation Policies
```
get_entity_settings_policies
  entity_uuid (required str) — UUID of the entity
```
Returns the settings/automation policies controlling which actions are automated for this entity.

---

## Proxy Routes (React App — localhost:4000)

These routes are served by `proxy/server.js` and consumed by `turboApi.js` in the React dashboard:

| Proxy route | Turbonomic REST endpoint | Notes |
|---|---|---|
| `GET /api/targets` | `GET /api/v3/targets` | All discovery targets (Kubernetes, Instana, etc.) |
| `GET /api/markets` | `GET /api/v3/markets` | All markets; real-time market has UUID `777777` |
| `GET /api/entities` | `GET /api/v3/entities?types=&limit=100` | Optional `?type=VirtualMachine` etc. |
| `GET /api/groups` | `GET /api/v3/groups?group_type=&limit=100` | Optional `?type=BusinessApplication` etc. |

> Note: `/turbo/*` prefix is **not used**. All proxy routes use `/api/*`.

---

## Step 3 — Task-Based Tool (Semantics Server Only)

The `fastmcp_server_semantics.py` server provides a higher-level tool that combines multiple API calls:

### get_entity_governance
```
get_entity_governance
  entity_uuid            (required str)              — UUID of the entity to analyze
  include_policy_details (optional bool, default True) — fetch full specs for each policy
```
**Returns a consolidated dict with:**
- `placement_policies` — policies controlling entity placement and relationships
- `automation_policies` — settings policies controlling action automation
- `policy_details` — full specification for each unique policy UUID (if `include_policy_details=True`)
- `summary` — counts of placement/automation policies, retrieval stats, and error flags
- `errors` — list of any partial failures (tool continues on non-fatal errors)

Use this tool when you need to audit why certain actions are or aren't being taken, understand
resource constraints, or review automation configuration for an entity in a single call.

---

## Step 4 — Common Entity Types

| Type String         | Description                          |
|---------------------|--------------------------------------|
| `VirtualMachine`    | Virtual machines                     |
| `PhysicalMachine`   | Physical hosts / bare-metal servers  |
| `Storage`           | Storage volumes / datastores         |
| `Application`       | Application components               |
| `DatabaseServer`    | Database server instances            |
| `VirtualDataCenter` | VMware virtual data centers          |
| `DataCenter`        | Physical data centers                |
| `Container`         | Kubernetes / Docker containers       |
| `ContainerPod`      | Kubernetes pods                      |
| `BusinessAccount`   | Cloud billing accounts               |

---

## Step 5 — Interpret and Present Results

### Entities
- Each entity has `uuid`, `displayName`, `entityType`, `state`, `severity`.
- `state` values: `ACTIVE`, `IDLE`, `UNKNOWN`, `SUSPENDED`.
- Use `uuid` values as input to action tools (e.g., `get_actions_by_scope`) or entity detail tools.

### Groups
- Groups bundle entities for policy or reporting purposes.
- `groupType` indicates whether the group is static or dynamic.

### Targets
- Targets are discovered infrastructure sources (probes).
- Check `status` field: `VALIDATED` = healthy connection, `VALIDATION_FAILED` = probe error.

### Markets
- The real-time market UUID is needed for some scoped queries.
- Additional markets represent "what-if" scenarios.

### Entity Statistics
- Statistics include commodity types like `CPU`, `MEM`, `STORAGE`, `NET_THROUGHPUT`.
- Each stat entry has `name`, `values` (with `avg`, `min`, `max`, `capacity`), and `units`.

### Entity Governance (get_entity_governance)
- `placement_policies` and `automation_policies` are lists of policy references (with `uuid` and `displayName`).
- `policy_details` is a dict keyed by policy UUID with the full policy specification.
- Check `summary.has_errors` — partial failures are non-fatal; some policies may still load.

---

## Step 6 — Common Workflows

### Workflow: Inventory Virtual Machines
1. Call `get_entities(entity_type="VirtualMachine", limit=100)`.
2. Summarise by `state` (active vs. idle vs. suspended).
3. Highlight any VMs in `UNKNOWN` state as potentially needing investigation.

### Workflow: Check Target Health
1. Call `get_targets()`.
2. Filter for targets where `status != "VALIDATED"`.
3. Report probe name, type, and error message for any failing targets.

### Workflow: List Business Application Groups
1. Call `get_groups(group_type="BusinessApplication")`.
2. For each group, list member count and display name.

### Workflow: Review Pending Reservations
1. Call `get_reservations(limit=50)`.
2. Show reservation name, requested resources, start/end dates, and status.

### Workflow: Audit Entity Governance
1. Obtain the `entity_uuid` (from `get_entities` or user input).
2. Call `get_entity_governance(entity_uuid=<uuid>)` (semantics server).
3. Review `placement_policies` and `automation_policies` counts in `summary`.
4. Inspect `policy_details` for specific constraints and automation settings.
5. If `summary.has_errors` is true, note which policies could not be retrieved from `errors`.

### Workflow: Investigate Resource Utilisation
1. Obtain the `entity_uuid` from `get_entities`.
2. Call `get_entity_stats(entity_uuid=<uuid>)` for current stats.
3. For a time range, call `get_entity_stats(entity_uuid=<uuid>, encoded_query="startDate=<ms>&endDate=<ms>")`.
4. Present CPU/memory/storage average, peak, and capacity values.

---

## Notes

- Entity type strings are case-sensitive — use the exact values from the Common Entity Types table above.
- Very large environments may return thousands of entities; always use `limit` to page safely.
- `get_entity_stats`, `get_entity_policies`, and `get_entity_settings_policies` are exposed via the entity_api in the semantics server; they may not be registered as MCP tools in `fastmcp_server.py`.
- `get_entity_governance` is only available when using `fastmcp_server_semantics.py`.
- All tools return a dict; on failure the dict contains an `"error"` key with a description.
