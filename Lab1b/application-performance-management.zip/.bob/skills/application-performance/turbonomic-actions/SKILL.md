---
name: turbonomic-actions
description: Use when the user wants to query, inspect, execute, accept, reject, or manage Turbonomic actions — covers get_actions, get_action_by_uuid, get_action_details, execute_action, get_action_policies, get_action_settings_policies, get_related_actions, get_action_details_resource_impact, reject_actions, get_overview_stats, and related action workflows. Also covers the React app proxy routes for actions.
---

# Turbonomic Actions

This skill guides you through interacting with Turbonomic actions via the MCP server tools or the React app proxy.

## Prerequisites

The Turbonomic MCP server must be running and connected. Verify with:
- Environment variables set: `TURBONOMIC_API_URL`, `TURBONOMIC_USERNAME`, `TURBONOMIC_PASSWORD`
- Server started via `python fastmcp_server.py` (basic) or `python fastmcp_server_semantics.py` (includes task-based tools)

---

## React App Proxy Routes (localhost:4000)

| Proxy route | Turbonomic REST endpoint | Notes |
|---|---|---|
| `GET /api/actions` | `GET /api/v3/markets/777777/actions?limit=100` | Returns up to 100 actions; market UUID `777777` is the real-time market |
| `POST /api/actions/:uuid/execute?accept=true` | `POST /api/v3/actions/{uuid}?accept=true` | Accept and execute an action |
| `POST /api/actions/:uuid/execute?accept=false` | `POST /api/v3/actions/{uuid}?accept=false` | Reject an action |

### Execute Action — confirmed working verb/path

The execute endpoint was discovered by probing: `POST /api/v3/actions/{uuid}?accept=true|false` returns `200 true` on success.

**PUT, PATCH, and POST without the `?accept=` param all return 500.** Only the query-param form works.

### Executable Action States

Only actions in these states can be executed:
- `READY` — action is ready to accept and execute
- `PENDING_ACCEPT` — action is awaiting manual approval

Actions in `SUCCEEDED`, `FAILED`, `REJECTED`, or `IN_PROGRESS` states cannot be executed.

### Action Fields (live data shape)

```json
{
  "uuid": "639583156236807",
  "actionType": "MOVE",
  "actionState": "READY",
  "actionMode": "MANUAL",
  "actionStateDescription": "READY_ACCEPT_AND_EXECUTE",
  "details": "Move Container Pod turbonomic/sustainability-… from worker-5 to worker-1",
  "target": {
    "displayName": "turbonomic/sustainability-57ff5ddbfd-2fcmm",
    "className": "ContainerPod",
    "uuid": "76627750784039"
  },
  "currentEntity": { "displayName": "itz-0z3jrp-worker-5", "className": "VirtualMachine" },
  "newEntity":     { "displayName": "itz-0z3jrp-worker-1", "className": "VirtualMachine" },
  "risk": {
    "subCategory": "Efficiency Improvement",
    "description": "itz-0z3jrp-worker-5 can be suspended to improve efficiency",
    "severity": "MINOR"
  },
  "executionCharacteristics": {
    "disruptiveness": "NON_DISRUPTIVE",
    "reversibility": "IRREVERSIBLE"
  }
}
```

> Note: `/turbo/*` prefix is **not used**. All proxy routes use `/api/*`.

---

## Step 1 — Determine the User's Intent

Ask what the user needs:
- List all pending actions → use `get_actions`
- Inspect a specific action → use `get_action_by_uuid` or `get_action_details`
- Full impact analysis of an action → use `get_action_details_resource_impact` (semantics server)
- Accept or reject an action → use `execute_action`
- Bulk-reject actions → use `reject_actions`
- View placement policies affecting an action → use `get_action_policies`
- View automation/settings policies affecting an action → use `get_action_settings_policies`
- Find related actions → use `get_related_actions`
- Get state change history → use `get_action_state_changes`
- Get workflow details for an action → use `get_workflow_details`
- Get actions within a scope → use `get_actions_by_scope`
- Get action statistics for scopes → use `get_action_stats_by_uuids`
- Get details for multiple actions at once → use `get_action_details_by_uuids`
- Get overview widget statistics → use `get_overview_stats`

---

## Step 2 — Tool Reference

### List Actions
```
get_actions
  limit  (optional int)   — max number of actions to return
  filter (optional str)   — filter criteria string
```
Example: `get_actions(limit=50)` returns the 50 most recent actions.

### Get Action by UUID
```
get_action_by_uuid
  action_uuid  (required str) — UUID of the action
  detail_level (optional str) — level of detail: "STANDARD" | "EXECUTION_PLAN" | "FULL"
```

### Get Action Details
```
get_action_details
  action_uuid (required str) — UUID of the action
```
Returns richer execution details than `get_action_by_uuid`.

### Get Action Details for Multiple UUIDs
```
get_action_details_by_uuids
  action_uuids (required list[str]) — list of action UUIDs
```
POST body: `{"uuids": [...]}` — batches lookups for efficiency.

### Execute (Accept or Reject) an Action
```
execute_action
  action_uuid            (required str)  — UUID of the action
  accept                 (required bool) — true = accept, false = reject
  for_maintenance_window (optional bool) — true if related to a maintenance window
```
⚠️ This is a **mutating** operation. Confirm with the user before calling.

### Bulk Reject Actions
```
reject_actions
  action_ids (required list[str]) — list of action IDs to reject
```
⚠️ Mutating. Confirm the list of IDs before calling.

### Get Action Placement Policies
```
get_action_policies
  action_uuid (required str) — UUID of the action
```
Returns placement/operational policies affecting the entities involved in the action.

### Get Action Automation Policies
```
get_action_settings_policies
  action_uuid (required str) — UUID of the action
```
Returns settings/automation policies controlling whether the action executes automatically.

### Get Related Actions
```
get_related_actions
  action_uuid (required str) — UUID of the action
```

### Get Action State Changes
```
get_action_state_changes
  action_uuid (required str) — UUID of the action
```
Returns the history of state transitions (e.g., PENDING → ACCEPTED → SUCCEEDED).

### Get Workflow Details
```
get_workflow_details
  action_uuid (required str) — UUID of the action
```
Returns the workflow/runbook details associated with the action's state changes.

### Get Actions by Scope
```
get_actions_by_scope
  scopes           (required list[str])      — list of scope UUIDs
  action_input     (required dict)           — query object for filtering actions
  related_type     (optional str)            — entity type related to the scopes
  cursor           (optional str)            — pagination cursor
  limit            (optional int)            — max results per page
  action_order_by  (optional str)            — field to order results by
  ascending        (optional bool, default True)
```

### Get Action Statistics by UUIDs (Scope-Based)
```
get_action_stats_by_uuids
  scopes       (required list[str]) — list of scope UUIDs
  action_input (required dict)      — query object for filtering action stats
```

### Get Overview Statistics
```
get_overview_stats
  (no parameters)
```
Returns aggregated statistics used for overview/dashboard widgets.

---

## Step 3 — Task-Based Tool (Semantics Server Only)

The `fastmcp_server_semantics.py` server provides a higher-level tool that combines multiple API calls:

### get_action_details_resource_impact
```
get_action_details_resource_impact
  action_uuid          (required str)              — UUID of the action to analyze
  include_entity_stats (optional bool, default True) — include resource statistics for involved entities
  stats_time_range     (optional str)              — time range as "startDate:endDate" in milliseconds
                                                     e.g. "1767740100653:1767774010065"
```
**Returns a consolidated dict with:**
- `action_info` — basic action data (detail_level="FULL")
- `action_details` — detailed action specifications
- `related_actions` — list + count of related actions
- `automation_policies` — settings policies governing this action
- `entity_stats` — per-entity resource statistics (if `include_entity_stats=True`)
- `summary` — high-level counts and error flags
- `errors` — list of any partial failures (tool continues on non-fatal errors)

Use this tool when you need to evaluate whether to execute an action, understand dependencies, or review automation policy compliance in a single call.

---

## Step 4 — Interpret and Present Results

- Actions include fields like `actionType`, `actionState`, `risk`, `target`, `currentEntity`, and `newEntity`.
- Common `actionType` values: `MOVE`, `RESIZE`, `SUSPEND`, `PROVISION`, `DELETE`, `RECONFIGURE`.
- Common `actionState` values: `PENDING_ACCEPT`, `ACCEPTED`, `REJECTED`, `SUCCEEDED`, `FAILED`.
- When listing many actions, group by `actionType` or `actionState` for clarity.
- For `execute_action` and `reject_actions`, confirm the UUID(s) with the user before calling.

---

## Step 5 — Common Workflows

### Workflow: Review and Accept Pending Actions
1. Call `get_actions(filter="PENDING_ACCEPT")` to list pending actions.
2. For each action of interest, call `get_action_details(action_uuid=<uuid>)`.
3. Optionally call `get_action_settings_policies(action_uuid=<uuid>)` to understand automation constraints.
4. Confirm with user, then call `execute_action(action_uuid=<uuid>, accept=True)`.

### Workflow: Full Impact Analysis Before Execution
1. Call `get_action_details_resource_impact(action_uuid=<uuid>)` (semantics server).
2. Review the returned `action_details`, `automation_policies`, and `entity_stats`.
3. Check `summary.has_errors` and `errors` list for any data retrieval issues.
4. Present findings to user and await approval before calling `execute_action`.

### Workflow: Investigate a Failed Action
1. Call `get_action_by_uuid(action_uuid=<uuid>, detail_level="FULL")`.
2. Call `get_action_state_changes(action_uuid=<uuid>)` to see the state transition history.
3. Call `get_workflow_details(action_uuid=<uuid>)` if a workflow/runbook was involved.
4. Call `get_related_actions(action_uuid=<uuid>)` to find correlated issues.

### Workflow: Bulk Reject a Category of Actions
1. Call `get_actions(filter=<criteria>)` to identify the unwanted actions.
2. Extract all `uuid` values from the response.
3. Confirm the list with the user.
4. Call `reject_actions(action_ids=[<uuid1>, <uuid2>, ...])`.

---

## Notes

- UUIDs are long alphanumeric strings — always copy them exactly from prior responses.
- Re-authentication happens automatically if the session expires (401/403 responses are retried).
- The `get_action_details_resource_impact` tool is only available when using `fastmcp_server_semantics.py`.
- All tools return a dict; on failure the dict contains an `"error"` key with a description.
