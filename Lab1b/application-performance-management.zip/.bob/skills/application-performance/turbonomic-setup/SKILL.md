---
name: turbonomic-setup
description: Use when the user wants to configure, start, deploy, or troubleshoot the Turbonomic MCP server or the React dashboard app — covers environment variables, local startup via start.sh, the Node.js proxy server, stdio vs SSE mode, Docker build/run, Kubernetes deployment, Bob MCP integration, and header-based authentication.
---

# Turbonomic Setup

Two separate components can be configured and started:

| Component | Purpose | Language |
|---|---|---|
| **React Dashboard App** | Visual dashboard for Turbonomic data | Node.js / Vite + React |
| **MCP Server** | Turbonomic tools for Bob / Claude Desktop | Python (fastmcp) |

---

## Part A — React Dashboard App

### Directory Layout
```
retail-capabilities-app/
  .env                   ← single config file (edit this)
  start.sh               ← one-command start/stop script
  src/
    App.jsx              ← 5-tab Carbon UI
    turboApi.js          ← fetch wrapper (relative /api/* paths)
  proxy/
    server.js            ← Node.js Express proxy (port 4000)
    .env.example         ← template — copy to ../.env
  vite.config.js         ← Vite dev server + proxy config
```

### Step 1 — Configure `.env`

The single config file is **`retail-capabilities-app/.env`**:

```env
# Full base URL of your Turbonomic instance (no trailing slash)
TURBO_BASE=https://turbonomic-turbonomic.apps.your-cluster.example.com

# Login credentials
TURBO_USER=administrator
TURBO_PASS=administrator

# Port the proxy listens on (Vite dev server proxies /api/* here automatically)
PROXY_PORT=4000
```

> The proxy reads this file via `dotenv` on startup. If `.env` is missing the proxy exits with a clear error message.

### Step 2 — Start with `start.sh`

```bash
cd retail-capabilities-app

./start.sh            # start proxy + React UI (background, logs to .logs/)
./start.sh stop       # stop both
./start.sh restart    # stop then start
./start.sh status     # show what is running
```

`start.sh` automatically:
- Validates `.env` exists
- Runs `npm install` in both `proxy/` and root if `node_modules` is absent
- Starts proxy on `:4000` then waits for the port to be live
- Starts Vite dev server on `:5173` then waits for the port to be live
- Writes all output to `.logs/proxy.log` and `.logs/vite.log`

Open the app at **`http://localhost:5173`**

### Step 3 — Manual Start (two terminals)

**Terminal 1 — proxy:**
```bash
cd retail-capabilities-app/proxy
node server.js
# Expected: [turbo-auth] session cookie stored
#           [proxy] :4000  turbonomic → https://...
```

**Terminal 2 — React UI:**
```bash
cd retail-capabilities-app
npm run dev
# Expected: VITE ready  →  http://localhost:5173/
```

### How the Proxy Works

```
Browser (localhost:5173)
  ↓  fetch /api/overview
Vite dev-server proxy  (vite.config.js — /api/* → localhost:4000)
  ↓
proxy/server.js  ← reads .env for TURBO_BASE / TURBO_USER / TURBO_PASS
  ↓  POST /api/v3/login?username=…&password=…  (cookie auth)
  ↓  GET  /api/v3/actions/stats/overview        (with JSESSIONID cookie)
Turbonomic instance
```

The proxy:
- Logs in to Turbonomic at startup and stores the `JSESSIONID` cookie
- Automatically re-authenticates on 401/403
- Disables SSL verification (`rejectUnauthorized: false`) for self-signed certs

### Proxy Routes

| Proxy endpoint | Turbonomic REST endpoint | Notes |
|---|---|---|
| `GET  /api/overview` | `GET /api/v3/actions/stats/overview` | 12 KPI stats |
| `GET  /api/actions` | `GET /api/v3/markets/777777/actions?limit=100` | Capped at 100 for performance |
| `POST /api/actions/:uuid/execute?accept=true\|false` | `POST /api/v3/actions/{uuid}?accept=true\|false` | Execute/reject an action |
| `GET  /api/notifications` | `GET /api/v3/notifications?limit=200` | |
| `GET  /api/policies` | `GET /api/v3/policies` | Placement policies |
| `GET  /api/settingspolicies` | `GET /api/v3/settingspolicies` | 35 entity-type policies |
| `GET  /api/targets` | `GET /api/v3/targets` | Discovery targets |
| `GET  /api/markets` | `GET /api/v3/markets` | Markets |
| `GET  /api/entities` | `GET /api/v3/entities` | Optional, with `?type=` |
| `GET  /api/groups` | `GET /api/v3/groups` | Optional, with `?type=` |
| `GET  /health` | — | Proxy health check |

### Validate All Endpoints

```bash
node -e "
const https = require('https');
// ... (run from project root)
" 
```

Or use `curl` after starting the proxy:
```bash
curl http://localhost:4000/health
curl http://localhost:4000/api/overview
curl http://localhost:4000/api/actions
```

### Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `ECONNREFUSED` on port 4000 | Proxy not running | Run `./start.sh` or `node proxy/server.js` |
| `Failed to fetch` in browser | Vite proxy not forwarding | Restart `npm run dev`; check `vite.config.js` has `/api` proxy |
| `[turbo-auth] login failed` | Wrong credentials or unreachable instance | Check `.env` `TURBO_BASE` / `TURBO_USER` / `TURBO_PASS` |
| Slow Actions Center tab (~5s) | Actions API is slow by design | Limit is capped at 100; parallelfetch on startup minimises wait |
| CSS build error (lightningcss) | Carbon CSS uses `@position-try` | `vite.config.js` has `css.transformer:'postcss'` + `cssMinify:false` |

---

## Part B — MCP Server Setup

### Step 1 — Choose a Server Entry Point

| Script | Tools included | Use when… |
|---|---|---|
| `fastmcp_server.py` | Basic tools only (actions, entities, cost) | Simple deployments; Docker default |
| `fastmcp_server_semantics.py` | Basic tools **plus** `get_action_details_resource_impact` and `get_entity_governance` | Composite/task-based tools needed |

### Step 2 — MCP Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `TURBONOMIC_API_URL` | ✅ | — | Base REST URL, e.g. `https://turbo.example.com` |
| `TURBONOMIC_USERNAME` | ✅ | — | Login username |
| `TURBONOMIC_PASSWORD` | ✅ | — | Login password |
| `MCP_HOST` | optional | `0.0.0.0` | Bind host |
| `MCP_PORT` | optional | `9000` | Bind port |
| `MCP_SERVER_MODE` | optional | `sse` | `sse` or `stdio` |
| `LOG_LEVEL` | optional | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |
| `LOG_TO_STDOUT` | optional | `false` | `true` for Docker/K8s |

### Step 3 — Local MCP Start

```bash
pip install -r requirements.txt

# SSE mode (default)
python fastmcp_server.py

# Semantics server, stdio mode (for Bob/Claude Desktop)
MCP_SERVER_MODE=stdio python fastmcp_server_semantics.py
```

### Step 4 — Docker MCP Setup

```bash
docker build -f docker/Dockerfile -t turbonomic-mcp-server:latest .

docker run -d \
  --name turbonomic-mcp-server \
  -p 9000:9000 \
  -e TURBONOMIC_API_URL="https://turbo.example.com" \
  -e TURBONOMIC_USERNAME="administrator" \
  -e TURBONOMIC_PASSWORD="your-password" \
  -e LOG_TO_STDOUT="true" \
  turbonomic-mcp-server:latest
```

### Step 5 — Kubernetes MCP Setup

```bash
cd k8s && chmod +x deploy.sh && ./deploy.sh
```

Manual:
```bash
kubectl create secret generic turbonomic-mcp-secret \
  --from-literal=username='admin' \
  --from-literal=password='pass'
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

### Step 6 — Bob MCP Integration

**stdio (Bob manages process):**
```json
{
  "mcpServers": {
    "turbonomic": {
      "command": "python",
      "args": ["fastmcp_server_semantics.py"],
      "cwd": "${workspaceFolder}",
      "env": {
        "TURBONOMIC_API_URL": "https://turbo.example.com",
        "TURBONOMIC_USERNAME": "administrator",
        "TURBONOMIC_PASSWORD": "your-password",
        "MCP_SERVER_MODE": "stdio"
      }
    }
  }
}
```

**SSE (connect to running server):**
```json
{
  "mcpServers": {
    "turbonomic": {
      "url": "http://localhost:9000",
      "transport": "sse"
    }
  }
}
```

---

## Notes

- Never commit credentials to source control. Use `.env` (git-ignored) or K8s secrets.
- The React app proxy and the MCP server are independent — you do not need both running simultaneously.
- For TLS in production, configure an Ingress with cert-manager.
