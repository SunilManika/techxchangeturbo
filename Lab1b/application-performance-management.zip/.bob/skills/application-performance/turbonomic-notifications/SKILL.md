---
name: turbonomic-notifications
description: Use when the user wants to query, filter, or acknowledge Turbonomic notifications (system alerts and events) — covers GET /notifications with severity/category filters and POST /notifications/acknowledge.
---

# Turbonomic Notifications

This skill guides you through querying and managing Turbonomic system notifications via the REST API.

## API Reference
- IBM Docs: https://www.ibm.com/docs/en/tarm/8.20.0?topic=endpoints-notifications-endpoint

---

## Endpoints

### GET /api/v3/notifications
Returns a paginated list of notifications (system alerts, events, audit messages).

**Query parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `limit` | int | — | Max number of notifications to return |
| `ascending` | bool | `false` | Sort order by time |
| `severity` | str | — | Filter: `CRITICAL`, `MAJOR`, `MINOR`, `WARNING`, `INFO`, `NORMAL` |
| `category` | str | — | Filter by category string |
| `acknowledged` | bool | — | `true` = only acknowledged; `false` = only unacknowledged |
| `startTime` | long | — | Epoch ms start of time window |
| `endTime` | long | — | Epoch ms end of time window |

**Example:**
```
GET /api/v3/notifications?limit=50&severity=CRITICAL&ascending=false
```

**Response shape** (list):
```json
[
  {
    "uuid": "...",
    "description": "Host cpu utilization is too high",
    "severity": "CRITICAL",
    "category": "Performance Assurance",
    "acknowledged": false,
    "shortDescription": "CPU Congestion",
    "relatedEntityUuid": "...",
    "relatedEntityType": "PhysicalMachine",
    "time": 1700000000000
  }
]
```

### POST /api/v3/notifications/acknowledge
Acknowledge one or more notifications.

**Request body:**
```json
{
  "uuids": ["<notification_uuid_1>", "<notification_uuid_2>"]
}
```

---

## Step 1 — Determine Intent

| User asks for…                    | Approach |
|-----------------------------------|----------|
| All recent notifications          | `GET /notifications?limit=100&ascending=false` |
| Only critical alerts              | `GET /notifications?severity=CRITICAL` |
| Unacknowledged only               | `GET /notifications?acknowledged=false` |
| Notifications in a time window    | `GET /notifications?startTime=<ms>&endTime=<ms>` |
| Acknowledge a notification        | `POST /notifications/acknowledge` with UUID list |

---

## Step 2 — Proxy Routes (localhost:4000)

| Proxy route | Turbonomic endpoint |
|---|---|
| `GET /api/notifications` | `GET /api/v3/notifications?limit=200&ascending=false` |

> Note: `/turbo/*` prefix is **not used**. All proxy routes use `/api/*`.

---

## Step 3 — Severity Reference

| Severity | Meaning |
|----------|---------|
| `CRITICAL` | Immediate action required; SLA at risk |
| `MAJOR` | Significant issue; investigate soon |
| `MINOR` | Non-urgent but worth reviewing |
| `WARNING` | Early warning; monitor closely |
| `INFO` / `NORMAL` | Informational; no action needed |

---

## Step 4 — Common Workflows

### Workflow: Show Unacknowledged Critical Alerts
1. Call `GET /api/v3/notifications?severity=CRITICAL&acknowledged=false&ascending=false`.
2. Display each notification's `description`, `category`, `relatedEntityType`, and `time`.
3. Offer to acknowledge via `POST /api/v3/notifications/acknowledge`.

### Workflow: Recent Notification Feed
1. Call `GET /api/v3/notifications?limit=50&ascending=false`.
2. Group by `severity` (CRITICAL → MAJOR → MINOR → INFO).
3. Show count per severity as summary badges.

### Workflow: Notification Audit for Time Window
1. Convert user-provided time range to epoch milliseconds.
2. Call `GET /api/v3/notifications?startTime=<ms>&endTime=<ms>&ascending=true`.
3. Present timeline of events.

---

## Notes
- Notifications are read-only (except acknowledge).
- The `acknowledged` flag does not delete the notification — it marks it as reviewed.
- `relatedEntityUuid` can be used to cross-reference with `GET /api/v3/entities/{uuid}`.
- Turbonomic may return `null` field values when the notification metadata is incomplete.
- The `time` field is epoch milliseconds — convert to ISO date for display.
