---
name: turbonomic-statistics
description: Use when the user wants to query Turbonomic statistics — covers the /stats endpoint for entity/group/market resource utilisation, the /actions/stats/overview endpoint for workload and savings overview, and entity-scoped stats via /entities/{uuid}/stats and /groups/{uuid}/stats.
---

# Turbonomic Statistics

This skill guides you through querying resource utilisation statistics from the Turbonomic REST API.

## API Reference
- IBM Docs: https://www.ibm.com/docs/en/tarm/8.20.6?topic=endpoints-statistics-endpoint

---

## Endpoints

### GET /api/v3/stats
Returns navigation links to the statistics sub-endpoints:
- `GET /api/v3/stats/{uuid}` — stats for a specific entity or group by UUID
- `GET /api/v3/entities/{uuid}/stats` — stats scoped to a single entity
- `GET /api/v3/groups/{uuid}/stats` — stats scoped to a group

### POST /api/v3/stats
Fetch statistics for one or more scopes.

**Request body:**
```json
{
  "scopes": [{ "uuid": "<entity_or_group_uuid>" }],
  "period": {
    "startDate": 1700000000000,
    "endDate":   1700086400000,
    "statistics": [
      { "name": "priceIndex" },
      { "name": "numActions" },
      { "name": "currentExpenses" },
      { "name": "projectedExpenses" }
    ]
  }
}
```

**Common statistic names:**
| Name | Description |
|------|-------------|
| `priceIndex` | Economic pressure / congestion score |
| `numActions` | Count of pending actions |
| `currentExpenses` | Current cost (cloud) |
| `projectedExpenses` | Projected cost after actions |
| `CPU` | CPU utilisation |
| `Mem` | Memory utilisation |
| `StorageAmount` | Storage used |
| `NetThroughput` | Network throughput |

### GET /api/v3/actions/stats/overview
Returns aggregated overview statistics for the dashboard widgets.
No request body or parameters required.

**Response shape** (list of stat objects):
```json
[
  { "name": "ReclaimVCPURequest",   "units": "mCores",    "value": 33666.0 },
  { "name": "ReclaimVMemRequest",   "units": "KB",        "value": 45178880.0 },
  { "name": "TotalWorkloads",                             "value": 311.0 },
  { "name": "OverProvisionedWorkloads",                   "value": 121.0 },
  { "name": "PotentialSavings",     "units": "$/month" },
  { "name": "NecessaryInvestments", "units": "$/month" }
]
```

**Key stat names returned:**
| Name | Meaning |
|------|---------|
| `ReclaimVCPURequest` | Reclaimable vCPU request capacity (mCores) |
| `ReclaimVMemRequest` | Reclaimable vMem request capacity (KB) |
| `ReclaimVCPULimit` | Reclaimable vCPU limit capacity (mCores) |
| `ReclaimVMemLimit` | Reclaimable vMem limit capacity (KB) |
| `TotalWorkloads` | Total number of workload entities |
| `OverProvisionedWorkloads` | Workloads with over-provisioned resources |
| `OnDemandPotentialSavings` | Cloud on-demand potential monthly savings |
| `PotentialSavings` | Total potential monthly savings |
| `NecessaryInvestments` | Required investments to resolve risk |

---

## Step 1 — Choose the Right Endpoint

| User asks for…                              | Endpoint to use |
|---------------------------------------------|-----------------|
| Dashboard / overview KPIs                   | `GET /actions/stats/overview` |
| Stats for a specific VM / host / container  | `GET /entities/{uuid}/stats` |
| Stats for a group of entities               | `GET /groups/{uuid}/stats` |
| Multi-scope or time-range stats             | `POST /stats` with body |

---

## Step 2 — Proxy Routes (localhost:4000)

| Proxy route | Turbonomic endpoint |
|---|---|
| `GET /api/overview` | `GET /api/v3/actions/stats/overview` |
| `GET /api/entities` | `GET /api/v3/entities` (optional, use `?type=VirtualMachine` etc.) |
| `GET /api/groups` | `GET /api/v3/groups` |

> Note: `/turbo/*` prefix is **not used**. All proxy routes use `/api/*`.

---

## Step 3 — Interpret Results

### Overview stats
- `value` is the numeric result; `units` is the unit string (may be absent for dimensionless counts).
- Stats without a `value` (e.g. savings with no cloud targets) are returned with `value` omitted.
- Group stats by prefix: `Reclaim*` = resource reclamation opportunities; `*Savings`/`*Investments` = cost.

### Entity / group stats
- Response is a list of stat snapshots, each with a `date`, `statistics` array, and per-commodity objects.
- Each commodity object has: `name`, `values.avg`, `values.min`, `values.max`, `values.capacity`, `units`.

---

## Step 4 — Common Workflows

### Workflow: Load Overview Dashboard
1. Call `GET /api/v3/actions/stats/overview`.
2. Display `TotalWorkloads`, `OverProvisionedWorkloads`, `ReclaimVCPURequest`, `ReclaimVMemRequest`.
3. **Note:** Savings/investment stats (`PotentialSavings`, `NecessaryInvestments`, `OnDemandPotentialSavings`, etc.) return `undefined` on on-prem instances without cloud billing targets — omit these from display.

### Workflow: Entity Resource Utilisation
1. Obtain `entity_uuid` via `GET /api/v3/entities?entity_type=VirtualMachine`.
2. Call `GET /api/v3/entities/{uuid}/stats`.
3. Extract CPU avg/max/capacity and Mem avg/max/capacity for display.

### Workflow: Time-Range Market Stats
1. Determine start/end epoch milliseconds.
2. Call `POST /api/v3/stats` with `scopes:[{uuid:"Market_uuid"}]` and desired stat names.
3. Plot time-series values.

---

## Notes
- `GET /api/v3/stats` (no UUID) returns only navigation links — not useful for data retrieval.
- Use `POST /api/v3/stats` for multi-scope or time-filtered queries.
- The overview endpoint (`/actions/stats/overview`) is the fastest path to dashboard KPIs.
- All monetary values are `$/month` unless otherwise specified in the `units` field.
